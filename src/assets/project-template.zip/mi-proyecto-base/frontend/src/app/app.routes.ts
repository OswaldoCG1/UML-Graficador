import { Routes } from '@angular/router';
import { MenuComponent } from './componentes/menu/menu.component';
import { CarroComponent } from './componentes/generados/carro/carro.component';

export const routes: Routes = [
    { path: '', redirectTo: '/menu', pathMatch: 'full' },
    { path: 'menu', component: MenuComponent },
    { path: 'carro', component: CarroComponent }
];
