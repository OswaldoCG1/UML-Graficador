const { Sequelize } = require('sequelize');

// Configuración de la conexión a la base de datos MySQL
const sequelize = new Sequelize('nombre_base_datos', 'usuario', 'contraseña', {
    host: 'localhost',
    dialect: 'mysql',
    logging: false, // Cambia a true para ver las consultas SQL en consola
});

// Probar la conexión
async function testConnection() {
    try {
        await sequelize.authenticate();
        console.log('Conexión a MySQL establecida correctamente.');
    } catch (error) {
        console.error('No se pudo conectar a la base de datos:', error);
    }
}

testConnection();

module.exports = sequelize;
