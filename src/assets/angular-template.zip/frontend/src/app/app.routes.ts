import { Routes } from '@angular/router';
import { MenuComponent } from './componentes/menu/menu.component';
import { CarroComponent } from './componentes/generados/carro/carro.component';
import { LoginComponent } from './login/login.component';
import { authGuard } from './auth.guard';

export const routes: Routes = [
    { path: 'login', component: LoginComponent },
    { path: '', redirectTo: '/menu', pathMatch: 'full' },
    { path: 'menu', component: MenuComponent, canActivate: [authGuard] },
    { path: 'carro', component: CarroComponent, canActivate: [authGuard] }
];
