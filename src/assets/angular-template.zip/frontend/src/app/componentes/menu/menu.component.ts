import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import * as go from 'gojs';

@Component({
  selector: 'app-menu',
  standalone: true,
  imports: [RouterLink, RouterOutlet],
  templateUrl: './menu.component.html',
  styleUrl: './menu.component.css'
})
export class MenuComponent {
  private diagram!: go.Diagram;
  private palette!: go.Palette;

  ngOnInit() {
    this.initDiagram();
    this.initPalette();
  }

  private initDiagram() {
    const $ = go.GraphObject.make;
    this.diagram = $(go.Diagram, "diagramDiv", {
      "undoManager.isEnabled": true,
      "draggingTool.dragsLink": true,
      "draggingTool.isGridSnapEnabled": true,
      "linkingTool.isUnconnectedLinkValid": true,
      "linkingTool.portGravity": 20,
      "relinkingTool.isUnconnectedLinkValid": true,
      "relinkingTool.portGravity": 20,
      "grid.visible": true,
      "grid.gridCellSize": new go.Size(10, 10),
      "commandHandler.archetypeGroupData": { isGroup: true, category: "OfNodes" }
    });

    // Plantilla para clases UML
    const nodeTemplate =
      $(go.Node, "Auto",
        {
          locationSpot: go.Spot.Center,
          fromSpot: go.Spot.AllSides,
          toSpot: go.Spot.AllSides
        },
        new go.Binding("location", "loc", go.Point.parse).makeTwoWay(go.Point.stringify),
        $(go.Shape, "Rectangle",
          {
            fill: "white",
            stroke: "black",
            strokeWidth: 2
          }),
        $(go.Panel, "Table",
          { defaultRowSeparatorStroke: "black" },
          // Nombre de la clase
          $(go.TextBlock,
            {
              row: 0,
              columnSpan: 2,
              margin: 8,
              alignment: go.Spot.Center,
              font: "bold 12pt sans-serif",
              editable: true
            },
            new go.Binding("text", "nombre").makeTwoWay()),

          // Separador
          $(go.RowColumnDefinition, { row: 1, separatorStroke: "black" }),

          // Panel de atributos con título y botón de agregar
          $(go.Panel, "Horizontal",
            {
              row: 1,
              alignment: go.Spot.Left,
              stretch: go.GraphObject.Horizontal,
              margin: new go.Margin(5, 5, 0, 5)
            },
            $("Button",
              {
                alignment: go.Spot.Right,
                width: 20,
                height: 20,
                margin: new go.Margin(0, 0, 0, 10),
                click: (e, obj) => {
                  const node = obj.part?.data;
                  if (node) {
                    const model = this.diagram.model;
                    model.startTransaction("add attribute");
                    const attr = { text: "+ nuevoAtributo: tipo" };
                    model.insertArrayItem(node.atributos, -1, attr);
                    model.commitTransaction("add attribute");
                  }
                }
              },
              $(go.TextBlock, "+", {
                font: "bold 10pt sans-serif",
                background: "#c8e6c9",
                stroke: "#2e7d32"
              })
            )
          ),

          // Lista de atributos
          $(go.Panel, "Vertical",
            {
              row: 2,
              margin: new go.Margin(5, 5),
              alignment: go.Spot.Left,
              defaultAlignment: go.Spot.Left,
              stretch: go.GraphObject.Horizontal,
              itemTemplate:
                $(go.Panel, "Horizontal",
                  {
                    alignment: go.Spot.Left,
                    stretch: go.GraphObject.Horizontal,
                    margin: new go.Margin(0, 0, 3, 0)
                  },
                  $(go.TextBlock,
                    {
                      editable: true,
                      margin: new go.Margin(0, 0, 0, 0),
                      font: "11pt sans-serif",
                      minSize: new go.Size(100, NaN),
                      stretch: go.GraphObject.Horizontal
                    },
                    new go.Binding("text", "text").makeTwoWay()),
                  $("Button",
                    {
                      alignment: go.Spot.Right,
                      width: 20,
                      height: 20,
                      margin: new go.Margin(0, 5, 0, 0),
                      click: (e, obj) => {
                        const node = obj.part?.data;
                        if (node) {
                          const idx = node.atributos.indexOf(obj.panel?.data);
                          const model = this.diagram.model;
                          model.startTransaction("remove attribute");
                          model.removeArrayItem(node.atributos, idx);
                          model.commitTransaction("remove attribute");
                        }
                      }
                    },
                    $(go.TextBlock, "×", {
                      font: "bold 10pt sans-serif",
                      background: "#ffcdd2",
                      stroke: "#d32f2f"
                    })
                  )
                )
            },
            new go.Binding("itemArray", "atributos")
          ),

          // Separador
          $(go.RowColumnDefinition, { row: 3, separatorStroke: "black" }),

          // Panel de métodos con título y botón de agregar
          $(go.Panel, "Horizontal",
            {
              row: 3,
              alignment: go.Spot.Left,
              stretch: go.GraphObject.Horizontal,
              margin: new go.Margin(5, 5, 0, 5)
            },
            $("Button",
              {
                alignment: go.Spot.Right,
                width: 20,
                height: 20,
                margin: new go.Margin(0, 0, 0, 10),
                click: (e, obj) => {
                  const node = obj.part?.data;
                  if (node) {
                    const model = this.diagram.model;
                    model.startTransaction("add method");
                    const method = { text: "+ nuevoMetodo(): tipo" };
                    model.insertArrayItem(node.metodos, -1, method);
                    model.commitTransaction("add method");
                  }
                }
              },
              $(go.TextBlock, "+", {
                font: "bold 10pt sans-serif",
                background: "#c8e6c9",
                stroke: "#2e7d32"
              })
            )
          ),

          // Lista de métodos
          $(go.Panel, "Vertical",
            {
              row: 4,
              margin: new go.Margin(5, 5),
              alignment: go.Spot.Left,
              defaultAlignment: go.Spot.Left,
              stretch: go.GraphObject.Horizontal,
              itemTemplate:
                $(go.Panel, "Horizontal",
                  {
                    alignment: go.Spot.Left,
                    stretch: go.GraphObject.Horizontal,
                    margin: new go.Margin(0, 0, 3, 0)
                  },
                  $(go.TextBlock,
                    {
                      editable: true,
                      margin: new go.Margin(0, 0, 0, 0),
                      font: "11pt sans-serif",
                      minSize: new go.Size(100, NaN),
                      stretch: go.GraphObject.Horizontal
                    },
                    new go.Binding("text", "text").makeTwoWay()),
                  $("Button",
                    {
                      alignment: go.Spot.Right,
                      width: 20,
                      height: 20,
                      margin: new go.Margin(0, 5, 0, 0),
                      click: (e, obj) => {
                        const node = obj.part?.data;
                        if (node) {
                          const idx = node.metodos.indexOf(obj.panel?.data);
                          const model = this.diagram.model;
                          model.startTransaction("remove method");
                          model.removeArrayItem(node.metodos, idx);
                          model.commitTransaction("remove method");
                        }
                      }
                    },
                    $(go.TextBlock, "×", {
                      font: "bold 10pt sans-serif",
                      background: "#ffcdd2",
                      stroke: "#d32f2f"
                    })
                  )
                )
            },
            new go.Binding("itemArray", "metodos")
          )
        )
      );

    this.diagram.nodeTemplate = nodeTemplate;

    // Plantilla para las relaciones
    this.diagram.linkTemplate =
      $(go.Link,
        {
          routing: go.Link.AvoidsNodes,
          curve: go.Link.JumpOver,
          corner: 5,
          relinkableFrom: true,
          relinkableTo: true,
          reshapable: true,
          resegmentable: true
        },
        $(go.Shape, { strokeWidth: 2 }),
        $(go.Shape, { toArrow: "Standard" })
      );

    this.diagram.model = new go.GraphLinksModel([], []);
  }

  private initPalette() {
    const $ = go.GraphObject.make;
    this.palette = $(go.Palette, "paletteDiv",
      {
        maxSelectionCount: 1,
        nodeTemplateMap: this.diagram.nodeTemplateMap,
        model: new go.GraphLinksModel([
          {
            key: "Clase",
            nombre: "NombreClase",
            atributos: [
              { text: "+ atributo1: tipo" },
              { text: "+ atributo2: tipo" }
            ],
            metodos: [
              { text: "+ metodo1(): tipo" },
              { text: "+ metodo2(): tipo" }
            ]
          }
        ])
      });
  }
}
