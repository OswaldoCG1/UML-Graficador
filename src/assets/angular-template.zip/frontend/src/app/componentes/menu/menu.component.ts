import { Component } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import * as go from 'gojs';
import { AuthService } from '../../auth.service';

AuthService
@Component({
  selector: 'app-menu',
  standalone: true,
  imports: [RouterLink, RouterOutlet],
  templateUrl: './menu.component.html',
  styleUrl: './menu.component.css'
})
export class MenuComponent {
  constructor(private auth: AuthService, private router: Router) {}

  logout() {
    this.auth.logout();
          this.router.navigate(['/login']);
  }

  isLoggedIn(): boolean {
    return this.auth.isLoggedIn();
  }
}
